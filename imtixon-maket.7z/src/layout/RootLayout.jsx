import { Outlet } from "react-router-dom"
import Header from "../components/header/Header"
import Footer from "../components/footer/Footer"
import { useEffect, useRef, useState } from "react"
const RootLayout = () => {
  const modeEl = useRef(null)
  useEffect(()=>{
    if(localStorage.getItem('mode') == 'dark'){
      modeEl.current.classList.add('dark-mode')
     }
  }, [])

  const onMode = () =>{
    if(localStorage.getItem('mode') == 'dark'){
      modeEl.current.classList.remove('dark-mode')
      localStorage.setItem('mode', '')

    }else{
      modeEl.current.classList.add('dark-mode')
      localStorage.setItem('mode', 'dark')
    }
    
  }
  return (
    <div ref={modeEl} className="modeEl">
      <Header onMode={onMode}/>
      <main className="main">
        <div className="container">
        <Outlet/>
        </div>
      </main>
      {/* <Footer/> */}
    </div>
  )
}

export default RootLayout
