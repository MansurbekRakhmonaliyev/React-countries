import './Footer.css'

const Footer = () => {
  return (
    <div>
      
    </div>
  )
}

export default Footer
